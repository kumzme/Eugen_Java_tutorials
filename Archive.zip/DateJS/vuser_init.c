vuser_init()
{
	// http://h30499.www3.hp.com/t5/HP-LoadRunner-and-Performance/How-to-use-JavaScript-in-your-HP-LoadRunner-scripts/ba-p/6197321#.UzredrHnZhF
	
	return 0;
}
