#define MYSQLSERVER "127.0.0.1"
#define MYSQLUSERNAME "root"
#define MYSQLPASSWORD ""
#define MYSQLDB	"test"
#define MYSQLPORT "3306"

#include "Ptt_Mysql.h"

vuser_init()
{
	

    return 0;
}

