Action()
{

	web_url("BL0", 
		"URL=http://api.zippopotam.us/GB/BL0", 
		"Resource=1", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t1.inf", 
		LAST);

	return 0;
}