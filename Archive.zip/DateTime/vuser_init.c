vuser_init()
{
	return 0;
}


//The following format codes are supported for lr_save_datetime.

//
//	%a - day of week, using locale's abbreviated weekday names
//	%A - day of week, using locale's full weekday names
//	%b - month, using locale's abbreviated month names
//	%B - month, using locale's full month names
//	%c - date and time as %x %X
// 	%d - day of month (01-31)
//  %H - hour (00-23)
//	%I - hour (00-12)
// 	%j - number of day in year (001-366)
//	%m - month number (01-12)
//	%M - minute (00-59)
//	%p - locale's equivalent of AM or PM, whichever is appropriate
//	%S - seconds (00-59)
//	%U - week number of year (01-52), Sunday is the first day of the week. Week number 01 is the first week with four or more January days in it.
//	%w - day of week; Sunday is day 0
//	%W - week number of year (01-52), Monday is the first day of the week. Week number 01 is the first week with four or more January days in it.
//  %x - date, using locale's date format
// 	%X - time, using locale's time format
//	%y - year within century (00-99)
//	%Y - year, including century (for example, 1988)
//	%Z - time zone abbreviation
//	%% - to include the "%" character in your output string 
