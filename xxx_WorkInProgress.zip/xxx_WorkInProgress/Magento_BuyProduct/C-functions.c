//
// To view/edit the script, click the Develop Script button
//
// This file defines the data and functions that will be used by EvalC
// steps in the script
//
// Note: this file is mandatory, do not delete it.
void main()
{
	
}