Action()
{

	/*1: Navigate to "http://89.238.153.133/index.php"*/

	web_add_cookie("external_no_cache=1; DOMAIN=89.238.153.133");

	web_url("index.php", 
		"URL=http://89.238.153.133/index.php", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t1.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=/skin/frontend/default/default/images/media/col_right_callout.jpg", ENDITEM, 
		"Url=/skin/frontend/default/default/images/ph_callout_left_top.gif", ENDITEM, 
		"Url=/skin/frontend/default/default/images/logo.gif", ENDITEM, 
		"Url=/skin/frontend/default/default/images/bkg_pipe1.gif", "Referer=http://89.238.153.133/skin/frontend/default/default/css/styles.css", ENDITEM, 
		"Url=/skin/frontend/default/default/images/btn_search.gif", "Referer=http://89.238.153.133/skin/frontend/default/default/css/styles.css", ENDITEM, 
		"Url=/skin/frontend/default/default/images/media/best_selling_img05.jpg", ENDITEM, 
		"Url=/skin/frontend/default/default/images/free_shipping_callout.jpg", ENDITEM, 
		"Url=/skin/frontend/default/default/images/media/best_selling_img01.jpg", ENDITEM, 
		"Url=/skin/frontend/default/default/images/home_main_callout.jpg", ENDITEM, 
		"Url=/skin/frontend/default/default/images/ph_callout_left_rebel.jpg", ENDITEM, 
		"Url=/skin/frontend/default/default/images/media/best_selling_img03.jpg", ENDITEM, 
		"Url=/skin/frontend/default/default/images/media/best_selling_img02.jpg", ENDITEM, 
		"Url=/skin/frontend/default/default/images/media/best_selling_img04.jpg", ENDITEM, 
		"Url=/skin/frontend/default/default/images/media/best_selling_img06.jpg", ENDITEM, 
		"Url=/skin/frontend/default/default/images/bkg_form-search.gif", "Referer=http://89.238.153.133/skin/frontend/default/default/css/styles.css", ENDITEM, 
		"Url=/skin/frontend/default/default/images/bkg_body.gif", "Referer=http://89.238.153.133/skin/frontend/default/default/css/styles.css", ENDITEM, 
		"Url=/skin/frontend/default/default/images/bkg_nav0.jpg", "Referer=http://89.238.153.133/skin/frontend/default/default/css/styles.css", ENDITEM, 
		"Url=/skin/frontend/default/default/images/bkg_header.jpg", "Referer=http://89.238.153.133/skin/frontend/default/default/css/styles.css", ENDITEM, 
		"Url=/skin/frontend/default/default/images/bkg_nav1.gif", "Referer=http://89.238.153.133/skin/frontend/default/default/css/styles.css", ENDITEM, 
		"Url=/skin/frontend/default/default/images/bkg_nav2.gif", "Referer=http://89.238.153.133/skin/frontend/default/default/css/styles.css", ENDITEM, 
		"Url=/skin/frontend/default/default/images/bkg_main1.gif", "Referer=http://89.238.153.133/skin/frontend/default/default/css/styles.css", ENDITEM, 
		"Url=/skin/frontend/default/default/images/bkg_block-title.gif", "Referer=http://89.238.153.133/skin/frontend/default/default/css/styles.css", ENDITEM, 
		"Url=/skin/frontend/default/default/images/bkg_main2.gif", "Referer=http://89.238.153.133/skin/frontend/default/default/css/styles.css", ENDITEM, 
		"Url=/skin/frontend/default/default/images/i_block-tags.gif", "Referer=http://89.238.153.133/skin/frontend/default/default/css/styles.css", ENDITEM, 
		"Url=/skin/frontend/default/default/images/bkg_block-actions.gif", "Referer=http://89.238.153.133/skin/frontend/default/default/css/styles.css", ENDITEM, 
		"Url=/skin/frontend/default/default/images/best_selling_tr_odd_bg.gif", "Referer=http://89.238.153.133/skin/frontend/default/default/css/styles.css", ENDITEM, 
		"Url=/skin/frontend/default/default/images/best_selling_tr_even_bg.gif", "Referer=http://89.238.153.133/skin/frontend/default/default/css/styles.css", ENDITEM, 
		"Url=/skin/frontend/default/default/images/i_block-list.gif", "Referer=http://89.238.153.133/skin/frontend/default/default/css/styles.css", ENDITEM, 
		"Url=/skin/frontend/default/default/images/i_block-cart.gif", "Referer=http://89.238.153.133/skin/frontend/default/default/css/styles.css", ENDITEM, 
		"Url=/skin/frontend/default/default/images/i_block-poll.gif", "Referer=http://89.238.153.133/skin/frontend/default/default/css/styles.css", ENDITEM, 
		"Url=/skin/frontend/default/default/images/bkg_pipe2.gif", "Referer=http://89.238.153.133/skin/frontend/default/default/css/styles.css", ENDITEM, 
		"Url=https://www.paypalobjects.com/en_GB/i/bnr/bnr_nowAccepting_150x60.gif", ENDITEM, 
		"Url=/skin/frontend/default/default/images/bkg_product-view.gif", "Referer=http://89.238.153.133/skin/frontend/default/default/css/styles.css", ENDITEM, 
		"Url=/skin/frontend/default/default/images/bkg_rating.gif", "Referer=http://89.238.153.133/skin/frontend/default/default/css/styles.css", ENDITEM, 
		"Url=/skin/frontend/default/default/images/bkg_divider1.gif", "Referer=http://89.238.153.133/skin/frontend/default/default/css/styles.css", ENDITEM, 
		"Url=/skin/frontend/default/default/images/slider_bg.gif", "Referer=http://89.238.153.133/skin/frontend/default/default/css/styles.css", ENDITEM, 
		"Url=/skin/frontend/default/default/images/magnifier_handle.gif", "Referer=http://89.238.153.133/skin/frontend/default/default/css/styles.css", ENDITEM, 
		"Url=/skin/frontend/default/default/images/bkg_product_collateral.gif", "Referer=http://89.238.153.133/skin/frontend/default/default/css/styles.css", ENDITEM, 
		"Url=/skin/frontend/default/default/images/bkg_grid.gif", "Referer=http://89.238.153.133/skin/frontend/default/default/css/styles.css", ENDITEM, 
		"Url=/skin/frontend/default/default/images/bkg_pipe3.gif", "Referer=http://89.238.153.133/skin/frontend/default/default/css/styles.css", ENDITEM, 
		"Url=/skin/frontend/default/default/images/i_tag_add.gif", "Referer=http://89.238.153.133/skin/frontend/default/default/css/styles.css", ENDITEM, 
		"Url=/skin/frontend/default/default/images/i_block-related.gif", "Referer=http://89.238.153.133/skin/frontend/default/default/css/styles.css", ENDITEM, 
		"Url=/skin/frontend/default/default/images/btn_checkout.gif", "Referer=http://89.238.153.133/skin/frontend/default/default/css/styles.css", ENDITEM, 
		"Url=/skin/frontend/default/default/images/i_msg-success.gif", "Referer=http://89.238.153.133/skin/frontend/default/default/css/styles.css", ENDITEM, 
		"Url=/skin/frontend/default/default/images/bkg_tfoot.gif", "Referer=http://89.238.153.133/skin/frontend/default/default/css/styles.css", ENDITEM, 
		"Url=/skin/frontend/default/default/images/bkg_th.gif", "Referer=http://89.238.153.133/skin/frontend/default/default/css/styles.css", ENDITEM, 
		"Url=/skin/frontend/default/default/images/i_discount.gif", "Referer=http://89.238.153.133/skin/frontend/default/default/css/styles.css", ENDITEM, 
		"Url=/skin/frontend/default/default/images/btn_trash.gif", "Referer=http://89.238.153.133/skin/frontend/default/default/css/styles.css", ENDITEM, 
		"Url=/skin/frontend/default/default/images/i_shipping.gif", "Referer=http://89.238.153.133/skin/frontend/default/default/css/styles.css", ENDITEM, 
		"Url=/skin/frontend/default/default/images/bkg_opc-title-off.gif", "Referer=http://89.238.153.133/skin/frontend/default/default/css/styles.css", ENDITEM, 
		"Url=/skin/frontend/default/default/images/bkg_checkout.gif", "Referer=http://89.238.153.133/skin/frontend/default/default/css/styles.css", ENDITEM, 
		"Url=/skin/frontend/default/default/images/i_arrow-top.gif", "Referer=http://89.238.153.133/skin/frontend/default/default/css/styles.css", ENDITEM, 
		LAST);

	/*4: Click on Sony VAIO VGN TXN27N/B... link*/

	web_url("sony-vaio-vgn-txn27n-b-11-1-notebook-pc.html", 
		"URL=http://89.238.153.133/index.php/sony-vaio-vgn-txn27n-b-11-1-notebook-pc.html", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://89.238.153.133/index.php", 
		"Snapshot=t2.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=../skin/frontend/default/default/images/slider_btn_zoom_out.gif", ENDITEM, 
		"Url=../media/catalog/product/cache/1/small_image/125x/9df78eab33525d08d6e5fb8d27136e95/a/c/acer-ferrari-3200-notebook-computer-pc.jpg", ENDITEM, 
		"Url=../skin/frontend/default/default/images/slider_btn_zoom_in.gif", ENDITEM, 
		"Url=../media/catalog/product/cache/1/small_image/125x/9df78eab33525d08d6e5fb8d27136e95/t/o/toshiba-m285-e-14.jpg", ENDITEM, 
		"Url=../media/catalog/product/cache/1/small_image/125x/9df78eab33525d08d6e5fb8d27136e95/a/p/apple-macbook-pro-ma464ll-a-15-4-notebook-pc.jpg", ENDITEM, 
		"Url=../media/catalog/product/cache/1/small_image/125x/9df78eab33525d08d6e5fb8d27136e95/s/o/sony-vaio-11-1-notebook-pc.jpg", ENDITEM, 
		"Url=../media/catalog/product/cache/1/thumbnail/50x/9df78eab33525d08d6e5fb8d27136e95/u/n/universal-camera-charger.jpg", ENDITEM, 
		"Url=../media/catalog/product/cache/1/image/9df78eab33525d08d6e5fb8d27136e95/s/o/sony-vaio-vgn-txn27n-b-11-1-notebook-pc.jpg", ENDITEM, 
		LAST);

	/*6: Type "1" in Qty textbox*/

	/*7: Click on Add to Cart button*/

	web_submit_data("250TaLL3Uu2cKWjj", 
		"Action=http://89.238.153.133/index.php/checkout/cart/add/uenc/aHR0cDovLzg5LjIzOC4xNTMuMTMzL2luZGV4LnBocC9zb255LXZhaW8tdmduLXR4bjI3bi1iLTExLTEtbm90ZWJvb2stcGMuaHRtbD9fX19TSUQ9VQ,,/product/27/form_key/250TaLL3Uu2cKWjj/", 
		"Method=POST", 
		"RecContentType=text/html", 
		"Referer=http://89.238.153.133/index.php/sony-vaio-vgn-txn27n-b-11-1-notebook-pc.html", 
		"Snapshot=t3.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=form_key", "Value=250TaLL3Uu2cKWjj", ENDITEM, 
		"Name=product", "Value=27", ENDITEM, 
		"Name=related_product", "Value=", ENDITEM, 
		"Name=qty", "Value=1", ENDITEM, 
		LAST);

	/*8: Click on Proceed to Checkout button*/

	web_url("onepage", 
		"URL=http://89.238.153.133/index.php/checkout/onepage/", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://89.238.153.133/index.php/checkout/cart/", 
		"Snapshot=t4.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=/js/varien/accordion.js", ENDITEM, 
		"Url=/skin/frontend/base/default/js/opcheckout.js", ENDITEM, 
		LAST);

	/*9: Select "Register" from Checkout as a Guest or... listbox*/

	/*10: Click on Continue button*/

	/*12: Type "John" in *First Name textbox*/

	web_submit_data("saveMethod", 
		"Action=http://89.238.153.133/index.php/checkout/onepage/saveMethod/", 
		"Method=POST", 
		"RecContentType=text/html", 
		"Referer=http://89.238.153.133/index.php/checkout/onepage/", 
		"Snapshot=t5.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=method", "Value=register", ENDITEM, 
		LAST);

	web_url("progress", 
		"URL=http://89.238.153.133/index.php/checkout/onepage/progress/?prevStep=billing", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://89.238.153.133/index.php/checkout/onepage/", 
		"Snapshot=t6.inf", 
		"Mode=HTML", 
		LAST);

	/*13: Type "Smith" in *Last Name textbox*/

	/*14: Type "" in Company textbox*/

	/*15: Type new Date().valueOf() "@mail.com" in *Email Address textbox*/

	/*16: Type "1 High Street" in *Address textbox*/

	/*17: Type "" in Street Address 2 textbox*/

	/*18: Type "Any City" in *City textbox*/

	/*20: Select "United Kingdom" from *Country listbox*/

	/*25: Type "M1 5AN" in *Zip/Postal Code textbox*/

	/*26: Select "United Kingdom" from *Country listbox*/

	/*27: Type "01234567895412" in *Telephone textbox*/

	/*35: Type ************ in *Password passwordbox*/

	/*38: Type ************ in *Confirm Password passwordbox*/

	/*39: Click on Continue button*/

	/*40: Click on Continue button*/

	lr_think_time(42);

	web_custom_request("saveBilling", 
		"URL=http://89.238.153.133/index.php/checkout/onepage/saveBilling/", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://89.238.153.133/index.php/checkout/onepage/", 
		"Snapshot=t7.inf", 
		"Mode=HTML", 
		"EncType=application/x-www-form-urlencoded; charset=UTF-8", 
		"Body=billing%5Baddress_id%5D=&billing%5Bfirstname%5D=John&billing%5Blastname%5D=Smith&billing%5Bcompany%5D=&billing%5Bemail%5D=1403798914637%40mail.com&billing%5Bstreet%5D%5B%5D=1%20High%20Street&billing%5Bstreet%5D%5B%5D=&billing%5Bcity%5D=Any%20City&billing%5Bregion_id%5D=&billing%5Bregion%5D=&billing%5Bpostcode%5D=M1%205AN&billing%5Bcountry_id%5D=GB&billing%5Btelephone%5D=01234567895412&billing%5Bfax%5D=&billing%5Bcustomer_password%5D=q2w3e4r5t6&billing%5Bconfirm_password%5D=q2w3e4r5t6&"
		"billing%5Bsave_in_address_book%5D=1&billing%5Buse_for_shipping%5D=1", 
		LAST);

	web_submit_data("getAdditional", 
		"Action=http://89.238.153.133/index.php/checkout/onepage/getAdditional/", 
		"Method=POST", 
		"RecContentType=text/html", 
		"Referer=http://89.238.153.133/index.php/checkout/onepage/", 
		"Snapshot=t8.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		LAST);

	web_url("progress_2", 
		"URL=http://89.238.153.133/index.php/checkout/onepage/progress/?prevStep=billing", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://89.238.153.133/index.php/checkout/onepage/", 
		"Snapshot=t9.inf", 
		"Mode=HTML", 
		LAST);

	web_url("progress_3", 
		"URL=http://89.238.153.133/index.php/checkout/onepage/progress/?prevStep=shipping", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://89.238.153.133/index.php/checkout/onepage/", 
		"Snapshot=t10.inf", 
		"Mode=HTML", 
		LAST);

	/*41: Select "Check / Money order" from checkmo Check / Money... radiogroup*/

	web_submit_data("saveShippingMethod", 
		"Action=http://89.238.153.133/index.php/checkout/onepage/saveShippingMethod/", 
		"Method=POST", 
		"RecContentType=text/html", 
		"Referer=http://89.238.153.133/index.php/checkout/onepage/", 
		"Snapshot=t11.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=shipping_method", "Value=flatrate_flatrate", ENDITEM, 
		LAST);

	web_url("progress_4", 
		"URL=http://89.238.153.133/index.php/checkout/onepage/progress/?prevStep=shipping_method", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://89.238.153.133/index.php/checkout/onepage/", 
		"Snapshot=t12.inf", 
		"Mode=HTML", 
		LAST);

	web_url("progress_5", 
		"URL=http://89.238.153.133/index.php/checkout/onepage/progress/", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://89.238.153.133/index.php/checkout/onepage/", 
		"Snapshot=t13.inf", 
		"Mode=HTML", 
		LAST);

	/*42: Click on Continue button*/

	web_submit_data("savePayment", 
		"Action=http://89.238.153.133/index.php/checkout/onepage/savePayment/", 
		"Method=POST", 
		"RecContentType=text/html", 
		"Referer=http://89.238.153.133/index.php/checkout/onepage/", 
		"Snapshot=t14.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=payment[method]", "Value=checkmo", ENDITEM, 
		LAST);

	/*43: Click on Place Order button*/

	web_url("progress_6", 
		"URL=http://89.238.153.133/index.php/checkout/onepage/progress/?prevStep=payment", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://89.238.153.133/index.php/checkout/onepage/", 
		"Snapshot=t15.inf", 
		"Mode=HTML", 
		LAST);

	return 0;
}
