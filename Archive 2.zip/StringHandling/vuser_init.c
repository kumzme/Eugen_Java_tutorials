vuser_init()
{
	// Functions in this script adapted from "Converting data types using C"
	// Originally at http://www.bish.co.uk/forum/index.php?topic=34.0
	
	return 0;
}
