//

char *xstrcat( char *dest, char *src ) 
{ 
while (*dest) dest++; 
while (*dest++ = *src++); 
return --dest;
}


vuser_init()
{
	return 0;
}
